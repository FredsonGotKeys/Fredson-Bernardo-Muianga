import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Briefcase, 
  User, 
  MessageCircle, 
  ArrowRight, 
  CheckCircle2, 
  FileText, 
  Edit3, 
  PlusCircle,
  Zap,
  Award,
  Star,
  Clock,
  Phone
} from 'lucide-react';

// --- Constantes ---
const TARGET_DATE = new Date('2026-04-07T00:00:00').getTime();
const WHATSAPP_NUMBER = "258846283051";

type View = 'home' | 'services' | 'expertise' | 'contact';

export default function App() {
  const [activeView, setActiveView] = useState<View>('home');
  const [loading, setLoading] = useState(true);
  const [timeLeft, setTimeLeft] = useState({
    days: 0, hours: 0, minutes: 0, seconds: 0
  });

  // --- Splash Screen Timeout ---
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  // --- Countdown Logic ---
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = TARGET_DATE - now;
      if (distance < 0) {
        clearInterval(timer);
        return;
      }
      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const pageVariants = {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  };

  return (
    <div className="min-h-screen bg-mz-black text-mz-white flex flex-col font-sans selection:bg-mz-gold selection:text-mz-black capulana-pattern">
      
      <AnimatePresence>
        {loading && (
          <motion.div 
            key="splash"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[100] bg-mz-black flex flex-col items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="relative"
            >
              <div className="w-32 h-32 rounded-full border-2 border-mz-gold/20 flex items-center justify-center">
                <div className="w-24 h-24 rounded-full bg-mz-gold flex items-center justify-center text-mz-black font-black text-4xl shadow-[0_0_50px_rgba(252,181,20,0.3)]">
                  FM
                </div>
              </div>
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                className="absolute inset-[-10px] border border-dashed border-mz-gold/40 rounded-full"
              />
            </motion.div>
            
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.8 }}
              className="mt-8 text-center"
            >
              <h2 className="font-serif text-2xl font-bold tracking-tight mb-2">Fredson Muianga</h2>
              <div className="flex items-center gap-2 text-mz-gold/60 text-[10px] font-bold uppercase tracking-[0.3em]">
                <span className="w-8 h-[1px] bg-mz-gold/20" />
                Expertise & Carreira
                <span className="w-8 h-[1px] bg-mz-gold/20" />
              </div>
            </motion.div>

            <div className="absolute bottom-12 w-48 h-[2px] bg-white/5 overflow-hidden rounded-full">
              <motion.div 
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="w-full h-full bg-mz-gold"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Blobs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[10%] -left-[10%] w-[80%] h-[40%] bg-mz-green/10 blur-[120px] rounded-full" />
        <div className="absolute top-[40%] -right-[10%] w-[60%] h-[40%] bg-mz-red/10 blur-[120px] rounded-full" />
        <div className="absolute -bottom-[10%] left-[20%] w-[70%] h-[30%] bg-mz-gold/10 blur-[120px] rounded-full" />
      </div>

      {/* Main Content Area */}
      <main className="flex-grow relative z-10 overflow-y-auto no-scrollbar pb-24">
        <AnimatePresence mode="wait">
          {activeView === 'home' && (
            <motion.div 
              key="home"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="px-6 pt-12 relative"
            >
              {/* Subtle Background Image & Pattern */}
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-20">
                <img 
                  src="https://lh3.googleusercontent.com/d/12v-6tVbS-i7Pa8Jn0sp2rQNwMuuUu0PG" 
                  alt="Background" 
                  className="w-full h-full object-cover scale-110 blur-[1px]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-mz-black via-mz-black/40 to-mz-black" />
                <div className="absolute inset-0 capulana-pattern opacity-10" />
              </div>

              {/* Floating Gold Particles */}
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
                {[...Array(20)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ 
                      opacity: 0, 
                      x: Math.random() * 400, 
                      y: Math.random() * 800 
                    }}
                    animate={{ 
                      opacity: [0, 0.6, 0],
                      y: [null, Math.random() * -300],
                      x: [null, (Math.random() - 0.5) * 150]
                    }}
                    transition={{ 
                      duration: 8 + Math.random() * 12, 
                      repeat: Infinity,
                      ease: "linear"
                    }}
                    className="absolute w-[2px] h-[2px] bg-mz-gold rounded-full blur-[0.5px]"
                  />
                ))}
              </div>

              <div className="relative z-10">
                {/* Upgraded Hero Badge */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="relative mb-10 group"
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-mz-gold to-mz-red rounded-full blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200 animate-pulse" />
                  <div className="relative inline-flex items-center gap-3 bg-mz-black/40 backdrop-blur-xl border border-mz-gold/30 px-6 py-3 rounded-full">
                    <div className="flex items-center justify-center w-6 h-6 rounded-full bg-mz-gold/20 text-mz-gold animate-bounce">
                      <Zap size={14} fill="currentColor" />
                    </div>
                    <span className="text-[11px] font-black text-mz-gold uppercase tracking-[0.2em]">
                      OPORTUNIDADE EXCLUSIVA
                    </span>
                  </div>
                </motion.div>
                
                <h1 className="font-serif text-6xl font-bold leading-[1.0] mb-8 tracking-tighter">
                  Capulana é <span className="text-transparent bg-clip-text bg-gradient-to-r from-mz-gold via-white to-mz-gold bg-[length:200%_auto] animate-gradient drop-shadow-[0_0_15px_rgba(252,181,20,0.3)]">identidade</span>. <br />
                  <motion.span 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 }}
                    className="italic font-light opacity-90 text-transparent bg-clip-text bg-gradient-to-r from-white via-mz-gold/50 to-white text-4xl block mt-2"
                  >
                    Currículo é oportunidade.
                  </motion.span>
                </h1>
                
                <p className="text-white/70 text-xl mb-12 leading-relaxed max-w-[90%]">
                  Neste Dia da Mulher Moçambicana, não celebre apenas quem tu és. <br />
                  <span className="text-mz-gold font-medium">Prepara-te para as oportunidades que estão à tua frente.</span>
                </p>

                {/* Upgraded Countdown - "Encha os olhos" */}
                <div className="grid grid-cols-4 gap-4 mb-12">
                  {[
                    { label: 'Dias', val: timeLeft.days },
                    { label: 'Horas', val: timeLeft.hours },
                    { label: 'Min', val: timeLeft.minutes },
                    { label: 'Seg', val: timeLeft.seconds },
                  ].map((item, idx) => (
                    <motion.div 
                      key={item.label}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.6 + (idx * 0.1) }}
                      className="relative group"
                    >
                      <div className="absolute -inset-0.5 bg-mz-gold/20 rounded-2xl blur opacity-0 group-hover:opacity-100 transition duration-500" />
                      <div className="relative glass-card !p-4 flex flex-col items-center justify-center border-mz-gold/20 bg-mz-black/40 backdrop-blur-2xl group-hover:border-mz-gold/50 transition-all duration-500 shadow-[0_0_20px_rgba(0,0,0,0.5)]">
                        <div className="text-4xl font-black text-mz-gold tabular-nums tracking-tighter mb-1 drop-shadow-[0_0_10px_rgba(252,181,20,0.5)]">
                          {String(item.val).padStart(2, '0')}
                        </div>
                        <div className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40 group-hover:text-mz-gold transition-colors">
                          {item.label}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <button 
                  onClick={() => setActiveView('services')}
                  className="btn-primary w-full relative group overflow-hidden"
                >
                  <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out" />
                  <div className="absolute -inset-1 bg-mz-gold blur opacity-30 group-hover:opacity-60 transition duration-500 animate-pulse" />
                  <span className="relative flex items-center gap-2">
                    Ver Promoção <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                  </span>
                </button>

                <div className="mt-16 relative">
                  <div className="absolute -top-8 left-0 text-[10px] uppercase tracking-[0.3em] text-mz-gold/40 font-bold">Assinado por</div>
                  <div className="glass-card flex items-center gap-5 border-mz-gold/20 bg-mz-gold/5">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-mz-gold rounded-full blur-[2px] opacity-30" />
                      <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-mz-gold relative z-10">
                        <img 
                          src="https://lh3.googleusercontent.com/d/1ifg0pwRbwg47CMLIRUCurbnl2Lwz3wZq" 
                          alt="Fredson Muianga" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>
                    <div>
                      <div className="font-serif text-lg font-bold text-white tracking-tight">Fredson Muianga</div>
                      <div className="text-[10px] uppercase tracking-widest text-mz-gold font-black opacity-80">Expertise que abre portas</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeView === 'services' && (
            <motion.div 
              key="services"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="px-6 pt-12 relative"
            >
              {/* Subtle Background Image for Services */}
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-10">
                <img 
                  src="https://lh3.googleusercontent.com/d/12v-6tVbS-i7Pa8Jn0sp2rQNwMuuUu0PG" 
                  alt="Background" 
                  className="w-full h-full object-cover grayscale blur-[3px]"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="relative z-10">
                <h2 className="font-serif text-4xl font-bold mb-10 tracking-tight">Nossos <span className="text-mz-gold">Serviços</span></h2>
                
                <div className="space-y-8">
                {[
                  { 
                    title: "Já tenho CV", 
                    desc: "Análise técnica detalhada do teu perfil.", 
                    vagas: "Envio para 10 vagas por ti",
                    icon: <FileText className="text-mz-green" />, 
                    price: "299 MT",
                    link: `https://wa.me/${WHATSAPP_NUMBER}?text=Olá%20Fredson!%20Quero%20a%20Revisão%20do%20meu%20CV.`
                  },
                  { 
                    title: "Melhoria de CV", 
                    desc: "Reformulação total focada em resultados.", 
                    vagas: "Envio para 10 vagas por ti",
                    icon: <Edit3 className="text-mz-gold" />, 
                    price: "299 MT", 
                    featured: true,
                    link: `https://wa.me/${WHATSAPP_NUMBER}?text=Olá%20Fredson!%20Quero%20melhorar%20o%20meu%20CV.`
                  },
                  { 
                    title: "CV do Zero", 
                    desc: "Criação integral personalizada para ti.", 
                    vagas: "Envio para 10 vagas por ti",
                    icon: <PlusCircle className="text-mz-red" />, 
                    price: "299 MT",
                    link: `https://wa.me/${WHATSAPP_NUMBER}?text=Olá%20Fredson!%20Quero%20um%20CV%20do%20zero.`
                  }
                ].map((service, i) => (
                  <motion.div 
                    key={service.title}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className={`relative group ${service.featured ? 'scale-[1.02]' : ''}`}
                  >
                    {service.featured && (
                      <div className="absolute -top-3 right-6 z-20 bg-gradient-to-r from-mz-gold to-mz-red text-mz-black text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg animate-bounce">
                        Mais Popular
                      </div>
                    )}
                    <div className={`glass-card relative overflow-hidden transition-all duration-500 border-white/5 group-hover:border-mz-gold/30 ${service.featured ? 'border-mz-gold/40 bg-mz-gold/5 shadow-[0_20px_50px_rgba(252,181,20,0.1)]' : ''}`}>
                      <div className="flex gap-5">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 transition-transform duration-500 group-hover:scale-110 ${service.featured ? 'bg-mz-gold/20 text-mz-gold' : 'bg-white/5 text-white/50'}`}>
                          {service.icon}
                        </div>
                        <div className="flex-grow">
                          <h3 className="font-bold text-xl mb-1 tracking-tight">{service.title}</h3>
                          <p className="text-sm text-white/50 mb-4 leading-relaxed">{service.desc}</p>
                          
                          {/* Patent Feature */}
                          <div className="flex items-center gap-2 bg-mz-gold/10 text-mz-gold text-[10px] font-black px-3 py-2 rounded-xl mb-5 w-fit border border-mz-gold/20">
                            <Zap size={12} fill="currentColor" /> {service.vagas}
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t border-white/5">
                            <div className="text-2xl font-black text-mz-gold tracking-tighter">{service.price}</div>
                            <a 
                              href={service.link} 
                              target="_blank" 
                              className={`text-xs font-bold px-6 py-2.5 rounded-xl transition-all duration-300 ${service.featured ? 'bg-mz-gold text-mz-black hover:shadow-[0_0_20px_rgba(252,181,20,0.4)]' : 'bg-white/10 hover:bg-white/20'}`}
                            >
                              Escolher
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeView === 'expertise' && (
            <motion.div 
              key="expertise"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="px-6 pt-12 relative"
            >
              {/* Subtle Background Image for Expertise */}
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-10">
                <img 
                  src="https://lh3.googleusercontent.com/d/12v-6tVbS-i7Pa8Jn0sp2rQNwMuuUu0PG" 
                  alt="Background" 
                  className="w-full h-full object-cover grayscale blur-[3px]"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="relative z-10">
                <h2 className="font-serif text-4xl font-bold mb-10 tracking-tight">A <span className="text-mz-gold">Expertise</span></h2>
                
                <div className="glass-card mb-10 border-mz-gold/20 bg-mz-gold/5 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-mz-gold/10 blur-[50px] rounded-full -mr-16 -mt-16 group-hover:bg-mz-gold/20 transition-colors duration-700" />
                  <div className="flex items-center gap-6 mb-8 relative z-10">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-mz-gold rounded-full blur-[2px] opacity-30" />
                      <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-mz-gold shadow-2xl">
                        <img 
                          src="https://lh3.googleusercontent.com/d/1ifg0pwRbwg47CMLIRUCurbnl2Lwz3wZq" 
                          alt="Fredson Muianga" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold tracking-tight">Fredson Muianga</h3>
                      <p className="text-xs uppercase tracking-widest text-mz-gold font-black opacity-80">Consultor de Carreiras & TI</p>
                    </div>
                  </div>
                  <p className="text-base text-white/80 leading-relaxed italic relative z-10 border-l-2 border-mz-gold/30 pl-6 py-2">
                    "Como vocês sabem — tudo que Fredson Muianga toca com a minha expertise, dá certo. Já ajudei dezenas de profissionais a conquistarem as suas vagas em Moçambique."
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: <Award className="text-mz-gold" />, label: "Resultados", val: "100%" },
                    { icon: <Star className="text-mz-green" />, label: "Satisfação", val: "Elite" },
                    { icon: <Zap className="text-mz-red" />, label: "Entrega", val: "48h" },
                    { icon: <CheckCircle2 className="text-mz-gold" />, label: "Sucesso", val: "+500" },
                  ].map((stat, idx) => (
                    <motion.div 
                      key={stat.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.2 + (idx * 0.1) }}
                      className="glass-card !p-5 text-center border-white/5 hover:border-mz-gold/30 transition-colors group"
                    >
                      <div className="flex justify-center mb-3 group-hover:scale-110 transition-transform">{stat.icon}</div>
                      <div className="text-xl font-black text-white mb-1">{stat.val}</div>
                      <div className="text-[10px] opacity-40 uppercase tracking-[0.2em] font-bold">{stat.label}</div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeView === 'contact' && (
            <motion.div 
              key="contact"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              className="px-6 pt-12 relative"
            >
              {/* Subtle Background Image for Contact */}
              <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden opacity-10">
                <img 
                  src="https://lh3.googleusercontent.com/d/12v-6tVbS-i7Pa8Jn0sp2rQNwMuuUu0PG" 
                  alt="Background" 
                  className="w-full h-full object-cover grayscale blur-[3px]"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="relative z-10">
                <h2 className="font-serif text-4xl font-bold mb-10 tracking-tight">Contacto</h2>
                
                <div className="glass-card bg-gradient-to-br from-mz-red/20 to-transparent border-mz-red/40 mb-10 relative overflow-hidden group">
                  <div className="absolute -inset-1 bg-mz-red blur opacity-10 group-hover:opacity-20 transition duration-1000 animate-pulse" />
                  <h3 className="text-2xl font-black mb-4 flex items-center gap-3 text-mz-red tracking-tight">
                    <Clock className="animate-pulse" /> Vagas Limitadas
                  </h3>
                  <p className="text-base text-white/80 leading-relaxed mb-8">
                    Esta promoção é exclusiva para o Dia da Mulher Moçambicana. Garanta a sua vaga antes que a agenda feche.
                  </p>
                  <a 
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=Olá%20Fredson!%20Quero%20garantir%20minha%20vaga%20na%20promoção.`}
                    target="_blank"
                    className="btn-primary w-full relative group overflow-hidden py-5"
                  >
                    <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 ease-in-out" />
                    <span className="relative flex items-center gap-3 text-lg">
                      Garantir Agora <Zap size={22} fill="currentColor" />
                    </span>
                  </a>
                </div>

                <div className="space-y-5">
                  <a href={`tel:+258846283051`} className="glass-card flex items-center gap-5 active:bg-white/10 hover:border-mz-green/30 transition-colors group">
                    <div className="w-14 h-14 glass rounded-2xl flex items-center justify-center text-mz-green group-hover:scale-110 transition-transform"><Phone size={24} /></div>
                    <div>
                      <div className="text-[10px] opacity-40 uppercase tracking-widest font-bold mb-1">Ligar</div>
                      <div className="text-lg font-black tracking-tight">+258 846 283 051</div>
                    </div>
                  </a>
                  
                  <a href={`https://wa.me/${WHATSAPP_NUMBER}`} className="glass-card flex items-center gap-5 active:bg-white/10 hover:border-[#25D366]/30 transition-colors group">
                    <div className="w-14 h-14 glass rounded-2xl flex items-center justify-center text-[#25D366] group-hover:scale-110 transition-transform"><MessageCircle size={24} /></div>
                    <div>
                      <div className="text-[10px] opacity-40 uppercase tracking-widest font-bold mb-1">WhatsApp</div>
                      <div className="text-lg font-black tracking-tight">Conversar Agora</div>
                    </div>
                  </a>
                </div>

                <div className="mt-12 text-center opacity-30 text-[10px] uppercase tracking-[0.2em] font-bold">
                  © 2026 Fredson Muianga <br /> Maputo, Moçambique
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 glass border-t border-white/10 px-6 py-4 flex justify-between items-center z-50 rounded-t-[2.5rem] shadow-[0_-20px_40px_rgba(0,0,0,0.5)]">
        <button onClick={() => setActiveView('home')} className={`nav-item ${activeView === 'home' ? 'active' : ''}`}>
          <Home size={24} />
          <span className="text-[10px] font-bold">Início</span>
        </button>
        <button onClick={() => setActiveView('services')} className={`nav-item ${activeView === 'services' ? 'active' : ''}`}>
          <Briefcase size={24} />
          <span className="text-[10px] font-bold">Serviços</span>
        </button>
        <button onClick={() => setActiveView('expertise')} className={`nav-item ${activeView === 'expertise' ? 'active' : ''}`}>
          <User size={24} />
          <span className="text-[10px] font-bold">Expertise</span>
        </button>
        <button onClick={() => setActiveView('contact')} className={`nav-item ${activeView === 'contact' ? 'active' : ''}`}>
          <MessageCircle size={24} />
          <span className="text-[10px] font-bold">Contacto</span>
        </button>
      </nav>

      {/* Floating WhatsApp FAB (Only on Home) */}
      {activeView === 'home' && (
        <motion.a 
          href={`https://wa.me/${WHATSAPP_NUMBER}`}
          target="_blank"
          initial={{ scale: 0, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          className="fixed bottom-28 right-6 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-2xl z-40 active:scale-90 transition-transform"
        >
          <MessageCircle size={28} fill="currentColor" />
        </motion.a>
      )}

    </div>
  );
}
